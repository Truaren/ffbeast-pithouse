/**
 * MOZA Pedals (Arduino Pro Micro) Plugin Module
 */

const DEVICE_INFO = {
  vendorId: 0x2341, // Default Arduino Leonardo/Micro VID
  productId: 0x8036, // Replace with your exact PID (e.g., 0x8037 or 0x9205)
  name: "Moza Pedals (Arduino)"
};

// Arduino `map(val, 240, 630, 0, 1023)` sets range to 0-1023
const DEFAULT_RAW_LIMITS = {
  throtl_min: 0,
  throtl_max: 1023,
  brake_min: 0,
  brake_max: 1023,
  clutch_min: 0,
  clutch_max: 1023
};

/**
 * Parses the raw HID byte buffer into raw pedal values (axis1, axis2, axis3).
 * MHeironimus Joystick.h default format with X and Y axes enabled:
 * buf[0] = Report ID (0x12)
 * buf[1..2] = X Axis (16-bit LE)
 * buf[3..4] = Y Axis (16-bit LE)
 */
function parseRaw(buf) {
  // Safe reader helper
  const safeU16 = (b, o) => b.length >= o + 2 ? b.readUInt16LE(o) : 0;
  
  return {
    axis1: safeU16(buf, 1), // X axis -> Gas/Throttle
    axis2: safeU16(buf, 3), // Y axis -> Brake
    axis3: 0 // No clutch
  };
}

/**
 * Parses raw HID telemetry byte buffers into normalized UI percentages (0 to 1).
 */
function parseTelemetry(data) {
  // Throttle (axis1)
  const throttle = calcRatio(data.raw.axis1, 0, 1023, false); 
  // Brake (axis2)
  const brake    = calcRatio(data.raw.axis2, 0, 1023, false);
  const clutch   = 0;

  return { throttle, brake, clutch };
}

function calcRatio(val, min, max, invert) {
  let ratio = 0;
  if (max > min) {
    const clamped = Math.max(min, Math.min(max, val));
    ratio = (clamped - min) / (max - min);
  }
  return invert ? 1 - ratio : ratio;
}

function applyHardwareDeadzones(pedal, rawBounds, deadzones) {
  const overrides = {};
  // Example for standard 0-1023 pedals (non-inverted)
  if (pedal === 'throttle') {
    const resting = rawBounds.throtl_min;
    const fullPress = rawBounds.throtl_max;
    const dist = fullPress - resting;
    overrides.throtl_min = Math.round(resting + dist * (deadzones.min / 100));
    overrides.throtl_max = Math.round(fullPress - dist * (deadzones.max / 100));
  } else if (pedal === 'brake') {
    const resting = rawBounds.brake_min;
    const fullPress = rawBounds.brake_max;
    const dist = fullPress - resting;
    overrides.brake_min = Math.round(resting + dist * (deadzones.min / 100));
    overrides.brake_max = Math.round(fullPress - dist * (deadzones.max / 100));
  } else if (pedal === 'clutch') {
    const resting = rawBounds.clutch_min;
    const fullPress = rawBounds.clutch_max;
    const dist = fullPress - resting;
    overrides.clutch_min = Math.round(resting + dist * (deadzones.min / 100));
    overrides.clutch_max = Math.round(fullPress - dist * (deadzones.max / 100));
  }
  return overrides;
}

// Arduino doesn't support Feature Reports by default for configuration
function decodeConfigStruct(buf) { return null; }
function encodeConfigStruct(config) { return Buffer.alloc(0); }

function applySoftwareCurve(pts, xIn) {
  if (xIn <= pts[0][0]) return pts[0][1];
  if (xIn >= pts[pts.length - 1][0]) return pts[pts.length - 1][1];
  for (let i = 0; i < pts.length - 1; i++) {
    const p1 = pts[i];
    const p2 = pts[i + 1];
    if (xIn >= p1[0] && xIn <= p2[0]) {
      const t = (xIn - p1[0]) / (p2[0] - p1[0]);
      return p1[1] + t * (p2[1] - p1[1]);
    }
  }
  return xIn;
}

module.exports = {
  DEVICE_INFO,
  DEFAULT_RAW_LIMITS,
  parseRaw,
  parseTelemetry,
  applyHardwareDeadzones,
  decodeConfigStruct,
  encodeConfigStruct,
  applySoftwareCurve
};
